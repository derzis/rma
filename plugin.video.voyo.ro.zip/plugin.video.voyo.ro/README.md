# Voyo
Video add-on [Kodi] (http://www.kodi.tv/) pentru vizionare conţinut video de pe [VOYO] (https://voyo.protv.ro/).
Necesită abonare oentru vizionarea conţinutului media de pe site.
